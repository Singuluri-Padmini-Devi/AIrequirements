from flask import Flask, request, jsonify, render_template
from werkzeug.utils import secure_filename
from langdetect import detect, DetectorFactory
import pytesseract
from PIL import Image
import os
import json
import fitz  # PyMuPDF
import pdfplumber
import csv
from whoosh.index import create_in
from whoosh.fields import Schema, TEXT
from whoosh.qparser import QueryParser
from whoosh.writing import AsyncWriter

# Initialize Flask app
app = Flask(__name__, template_folder='templates', static_folder='static')

# Configuration
UPLOAD_FOLDER = 'uploads/'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'tiff', 'jfif', 'webp', 'bmp', 'pdf'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure the upload folder exists
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Set up Whoosh index
schema = Schema(content=TEXT(stored=True))
index_dir = "index"
if not os.path.exists(index_dir):
    os.mkdir(index_dir)
ix = create_in(index_dir, schema)

# Helper functions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def extract_text_from_image(image_path):
    try:
        image = Image.open(image_path)
        text = pytesseract.image_to_string(image)
        return text
    except Exception as e:
        return str(e)

def extract_text_from_pdf(pdf_path):
    text = ""
    try:
        pdf_document = fitz.open(pdf_path)
        for page_num in range(len(pdf_document)):
            page = pdf_document.load_page(page_num)
            page_text = page.get_text()
            text += page_text + "\n"
        
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                text += page_text + "\n"
    except Exception as e:
        return f"Error extracting text: {e}"
    return text

def index_text(text):
    writer = AsyncWriter(ix)
    writer.add_document(content=text)
    writer.commit()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)

        if filename.lower().endswith('.pdf'):
            text = extract_text_from_pdf(file_path)
        else:
            text = extract_text_from_image(file_path)

        index_text(text)  # Index the text

        json_output = json.dumps({'text': text}, indent=4)
        #csv_output = 'text\n' + text.replace('\n', '\n')
        csv_output = 'text\n' + '"' + text.replace('"', '""').replace('\n', '\\n') + '"'

        return jsonify({
            'text': text,
            'json': json_output,
            'csv': csv_output
        })
    return jsonify({'error': 'Invalid file type'}), 400

@app.route('/search', methods=['POST'])
def search_text():
    data = request.json
    query_str = data.get('query', '').strip()
    
    if not query_str:
        return jsonify({'error': 'Query not provided'}), 400
    
    results = []
    with ix.searcher() as searcher:
        query = QueryParser("content", ix.schema).parse(query_str)
        search_results = searcher.search(query, limit=None)
        
        results = [hit['content'] for hit in search_results]

    return jsonify({'results': results})

if __name__ == '__main__':
    app.run(debug=True)
