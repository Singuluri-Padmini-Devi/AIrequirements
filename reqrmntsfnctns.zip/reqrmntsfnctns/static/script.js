document.addEventListener('DOMContentLoaded', function() {
    const uploadForm = document.getElementById('upload-form');
    const searchForm = document.getElementById('search-form');
    const resultDiv = document.getElementById('result');
    const searchResultsDiv = document.getElementById('search-results');

    uploadForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(uploadForm);
        const fileInput = document.getElementById('file-input');
        const formatSelect = document.getElementById('format-select');

        if (fileInput.files.length === 0) {
            resultDiv.innerHTML = '<p style="color: red;">Please select a file.</p>';
            return;
        }

        resultDiv.innerHTML = '<p>Processing your file, please wait...</p>';

        fetch('/upload', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(data => {
                    throw new Error(data.error || 'An error occurred');
                });
            }
            return response.json();
        })
        .then(data => {
            const format = formatSelect.value;

            let output;
            if (format === 'text') {
                output = `<h3>Extracted Text:</h3><pre>${data.text}</pre>`;
            } else if (format === 'json') {
                output = `<h3>JSON Output:</h3><pre>${data.json}</pre>`;
            } else if (format === 'csv') {
                output = `<h3>CSV Output:</h3><pre>${data.csv}</pre>`;
            }

            resultDiv.innerHTML = output;
        })
        .catch(error => {
            resultDiv.innerHTML = `<p style="color: red;">An error occurred: ${error.message}</p>`;
        });
    });

    searchForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const searchQuery = document.getElementById('search-query').value.trim();

        if (!searchQuery) {
            searchResultsDiv.innerHTML = '<p style="color: red;">Please enter a search query.</p>';
            return;
        }

        searchResultsDiv.innerHTML = '<p>Searching, please wait...</p>';

        fetch('/search', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                query: searchQuery
            })
        })
        .then(response => {
            if (!response.ok) {
                return response.json().then(data => {
                    throw new Error(data.error || 'An error occurred');
                });
            }
            return response.json();
        })
        .then(data => {
            if (data.results.length > 0) {
                searchResultsDiv.innerHTML = '<h3>Search Results:</h3><ul>' +
                    data.results.map(line => `<li>${line}</li>`).join('') +
                    '</ul>';
            } else {
                searchResultsDiv.innerHTML = '<p>No results found.</p>';
            }
        })
        .catch(error => {
            searchResultsDiv.innerHTML = `<p style="color: red;">An error occurred: ${error.message}</p>`;
        });
    });
});
